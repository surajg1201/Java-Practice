package textgen;public class MyLinkedListTest {
}
